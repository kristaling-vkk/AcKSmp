package ac.grim.grimac.checks.impl.prediction;

import ac.grim.grimac.GrimAPI;
import ac.grim.grimac.checks.debug.AbstractDebugHandler;
import ac.grim.grimac.checks.type.PostPredictionListener;
import ac.grim.grimac.command.commands.GrimLog;
import ac.grim.grimac.platform.api.sender.Sender;
import ac.grim.grimac.player.GrimPlayer;
import ac.grim.grimac.predictionengine.UncertaintyHandler;
import ac.grim.grimac.utils.anticheat.update.PredictionComplete;
import ac.grim.grimac.utils.data.KnownInput;
import ac.grim.grimac.utils.lists.EvictingQueue;
import ac.grim.grimac.utils.math.Vector3dm;
import com.github.retrooper.packetevents.PacketEvents;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.stream.Collectors;

public class DebugHandler extends AbstractDebugHandler implements PostPredictionListener {
    private static final Component GRAY_ARROW = MiniMessage.miniMessage().deserialize("<gray>→0.03→</gray>");
    private static final Component P_PREFIX = MiniMessage.miniMessage().deserialize("<reset>P: </reset>");
    private static final Component A_PREFIX = MiniMessage.miniMessage().deserialize("<reset>A: </reset>");
    private static final Component O_PREFIX = MiniMessage.miniMessage().deserialize("<reset>O: </reset>");
    private static final int DEFAULT_BUFFER_SIZE = 500;

    public enum Filter { FLAGS_ONLY, ELYTRA, THRESHOLD }

    public static final class DebugSettings {
        private final EnumSet<Filter> filters;
        private double threshold;
        private int timeoutSeconds;
        private int bufferSize;

        public DebugSettings() {
            this.filters = EnumSet.noneOf(Filter.class);
            this.threshold = 0.001;
            this.timeoutSeconds = 0;
            this.bufferSize = DEFAULT_BUFFER_SIZE;
        }

        public DebugSettings(DebugSettings other) {
            this.filters = EnumSet.copyOf(other.filters.isEmpty() ? EnumSet.noneOf(Filter.class) : other.filters);
            this.threshold = other.threshold;
            this.timeoutSeconds = other.timeoutSeconds;
            this.bufferSize = other.bufferSize;
        }

        public Set<Filter> filters() { return filters; }
        public boolean hasFilter(Filter f) { return filters.contains(f); }
        public void addFilter(Filter f) { filters.add(f); }
        public void removeFilter(Filter f) { filters.remove(f); }
        public void resetFilters() { filters.clear(); }
        public boolean isFiltered() { return !filters.isEmpty(); }

        public double threshold() { return threshold; }
        public void setThreshold(double t) { this.threshold = t; }
        public int timeoutSeconds() { return timeoutSeconds; }
        public void setTimeoutSeconds(int t) { this.timeoutSeconds = t; }
        public int bufferSize() { return bufferSize; }
        public void setBufferSize(int s) { this.bufferSize = s; }

        public String filtersString() {
            if (filters.isEmpty()) return "ALL";
            return filters.stream().map(Enum::name).collect(Collectors.joining(", "));
        }
    }

    private final CopyOnWriteArraySet<GrimPlayer> listeners = new CopyOnWriteArraySet<>();
    private final Map<GrimPlayer, DebugSettings> listenerSettings = new ConcurrentHashMap<>();
    private final Map<GrimPlayer, Long> listenerStartTime = new ConcurrentHashMap<>();
    private boolean outputToConsole = false;

    private EvictingQueue<String> pasteBuffer = new EvictingQueue<>(DEFAULT_BUFFER_SIZE);

    private static final ConcurrentHashMap<String, DebugSettings> PENDING_SETTINGS = new ConcurrentHashMap<>();

    public DebugHandler(GrimPlayer player) {
        super(player);
    }

    public static DebugSettings getOrCreatePendingSettings(String senderKey) {
        return PENDING_SETTINGS.computeIfAbsent(senderKey, k -> new DebugSettings());
    }

    public void resizeBuffer(int newSize) {
        EvictingQueue<String> newBuffer = new EvictingQueue<>(newSize);
        newBuffer.addAll(pasteBuffer);
        pasteBuffer = newBuffer;
    }

    @Override
    public void onPredictionComplete(final PredictionComplete predictionComplete) {
        if (!predictionComplete.isChecked()) return;

        double offset = predictionComplete.getOffset();

        if (listeners.isEmpty() && !outputToConsole) return;
        if (player.predictedVelocity.vector.lengthSquared() == 0 && offset == 0) return;

        checkTimeouts();

        String color = pickColor(offset, offset);
        boolean isFlag = !color.equals("gray") && !color.equals("green");

        Vector3dm predicted = player.predictedVelocity.vector;
        Vector3dm actually = player.actualMovement;

        String xColor = pickColor(Math.abs(predicted.getX() - actually.getX()), offset);
        String yColor = pickColor(Math.abs(predicted.getY() - actually.getY()), offset);
        String zColor = pickColor(Math.abs(predicted.getZ() - actually.getZ()), offset);

        Component p = Component.empty()
                .append(P_PREFIX.color(NamedTextColor.NAMES.value(color)))
                .append(Component.text(predicted.getX()).color(NamedTextColor.NAMES.value(xColor)))
                .append(Component.space())
                .append(Component.text(predicted.getY()).color(NamedTextColor.NAMES.value(yColor)))
                .append(Component.space())
                .append(Component.text(predicted.getZ()).color(NamedTextColor.NAMES.value(zColor)));

        Component a = Component.empty()
                .append(A_PREFIX.color(NamedTextColor.NAMES.value(color)))
                .append(Component.text(actually.getX()).color(NamedTextColor.NAMES.value(xColor)))
                .append(Component.space())
                .append(Component.text(actually.getY()).color(NamedTextColor.NAMES.value(yColor)))
                .append(Component.space())
                .append(Component.text(actually.getZ()).color(NamedTextColor.NAMES.value(zColor)));

        String canSkipTick = (player.couldSkipTick + " ").substring(0, 1);
        String actualMovementSkip = (player.skippedTickInActualMovement + "").charAt(0) + " ";
        Component o = Component.empty()
                .append(Component.text(canSkipTick).color(NamedTextColor.GRAY))
                .append(GRAY_ARROW)
                .append(Component.text(actualMovementSkip).color(NamedTextColor.GRAY))
                .append(O_PREFIX.color(NamedTextColor.NAMES.value(color)))
                .append(Component.text(offset));

        int glideChange = player.uncertaintyHandler.lastGlidingChange.getTicksSince();
        int statusChange = player.uncertaintyHandler.lastFlyingStatusChange.getTicksSince();
        boolean showGlide = player.isGliding || player.wasGliding || glideChange < 40 || statusChange < 40;
        String elytraState = "";
        if (showGlide) {
            String chestType = player.inventory.getChestplate().getType() == com.github.retrooper.packetevents.protocol.item.type.ItemTypes.ELYTRA ? "E" : "-";
            double dy = predicted.getY() - actually.getY();
            double dx = predicted.getX() - actually.getX();
            double dz = predicted.getZ() - actually.getZ();
            elytraState = " G:" + (player.isGliding ? "1" : "0") + (player.wasGliding ? "1" : "0")
                    + " cg:" + (player.canGlide() ? "1" : "0")
                    + " cp:" + chestType
                    + " fly:" + (player.isFlying ? "1" : "0")
                    + " gnd:" + (player.onGround ? "1" : "0") + (player.lastOnGround ? "1" : "0")
                    + " vCol:" + (player.verticalCollision ? "1" : "0")
                    + " hCol:" + (player.horizontalCollision ? "1" : "0")
                    + " v:" + String.format("%.2f", player.clientVelocity.length())
                    + " av:" + String.format("%.2f", player.actualMovement.length())
                    + " dXYZ:" + String.format("%+.2f/%+.2f/%+.2f", dx, dy, dz)
                    + " fw:" + player.fireworks.getMaxFireworksAppliedPossible()
                    + " gc:" + (glideChange > 99 ? "-" : String.valueOf(glideChange))
                    + " sc:" + (statusChange > 99 ? "-" : String.valueOf(statusChange))
                    + " p:" + player.getTransactionPing() + "ms";
            o = o.append(Component.text(elytraState).color(NamedTextColor.AQUA));
        }

        String uncertaintyLine = isFlag ? describeUncertainty() : "";
        String causeLine = isFlag ? describeCause() : "";
        Component u = uncertaintyLine.isEmpty() ? null
                : Component.text(uncertaintyLine).color(NamedTextColor.DARK_AQUA);
        Component w = causeLine.isEmpty() ? null
                : Component.text(causeLine).color(NamedTextColor.DARK_PURPLE);

        String plainLine = "P: " + predicted.getX() + " " + predicted.getY() + " " + predicted.getZ()
                + " | A: " + actually.getX() + " " + actually.getY() + " " + actually.getZ()
                + " | O: " + offset + elytraState
                + (uncertaintyLine.isEmpty() ? "" : "\n" + uncertaintyLine)
                + (causeLine.isEmpty() ? "" : "\n" + causeLine);
        pasteBuffer.add(plainLine);

        String prefix = player.platformPlayer == null ? "null" : player.platformPlayer.getName() + " ";
        Component prefixComponent = Component.text(prefix);

        for (GrimPlayer listener : listeners) {
            DebugSettings settings = listenerSettings.getOrDefault(listener, new DebugSettings());
            if (!shouldSend(settings, offset, isFlag)) continue;

            Component listenerPrefix = listener == player ? Component.empty() : prefixComponent;
            listener.sendMessage(listenerPrefix.append(p));
            listener.sendMessage(listenerPrefix.append(a));
            listener.sendMessage(listenerPrefix.append(o));
            if (u != null) listener.sendMessage(listenerPrefix.append(u));
            if (w != null) listener.sendMessage(listenerPrefix.append(w));
        }

        listeners.removeIf(l -> l.platformPlayer != null && !l.platformPlayer.isOnline());

        if (outputToConsole) {
            Sender consoleSender = GrimAPI.INSTANCE.getPlatformServer().getConsoleSender();
            consoleSender.sendMessage(p);
            consoleSender.sendMessage(a);
            consoleSender.sendMessage(o);
            if (u != null) consoleSender.sendMessage(u);
            if (w != null) consoleSender.sendMessage(w);
        }
    }

    private String describeCause() {
        StringBuilder line = new StringBuilder("W: ");
        String branch = OffsetHandler.describeBranch(player.predictedVelocity);
        line.append(branch.isEmpty() ? "plain movement" : branch);
        line.append(" | ").append(player.uncertaintyHandler.describeBuild(player.predictedVelocity.vector));
        line.append(String.format(Locale.ROOT, " | spd %.4f fric %.4f grav %.4f",
                player.speed, player.friction, player.gravity));
        line.append(" | gnd ").append(player.onGround ? "1" : "0").append(player.lastOnGround ? "1" : "0")
                .append(" col h").append(player.horizontalCollision ? "1" : "0")
                .append("v").append(player.verticalCollision ? "1" : "0");
        line.append(" | pos ").append(player.packetStateData.didLastMovementIncludePosition ? "1" : "0")
                .append(" tp ").append(player.packetStateData.lastPacketWasTeleport ? "1" : "0")
                .append(" dup ").append(player.packetStateData.lastPacketWasOnePointSeventeenDuplicate ? "1" : "0");
        line.append(" | ").append(describeInput(player));
        return line.toString();
    }

    public static String describeInput(GrimPlayer player) {
        if (!player.supportsEndTick()) return "input n/a";
        KnownInput input = player.packetStateData.knownInput;
        return "input F" + (input.forward() ? "1" : "0") + " B" + (input.backward() ? "1" : "0")
                + " L" + (input.left() ? "1" : "0") + " R" + (input.right() ? "1" : "0")
                + " J" + (input.jump() ? "1" : "0") + " S" + (input.shift() ? "1" : "0")
                + " Sp" + (input.sprint() ? "1" : "0");
    }

    private String describeUncertainty() {
        UncertaintyHandler uncertainty = player.uncertaintyHandler;
        StringBuilder line = new StringBuilder("U: ");
        line.append(String.format(java.util.Locale.ROOT, "miss x%+.4f y%+.4f z%+.4f", uncertainty.offsetX, uncertainty.offsetY, uncertainty.offsetZ));

        String box = uncertainty.describeBox();
        line.append(" | slack ").append(box.isEmpty() ? "none" : box);

        String sources = uncertainty.describeSources(6);
        if (!sources.isEmpty()) line.append(" | from ").append(sources);

        String cut = uncertainty.describeReduction();
        if (!cut.isEmpty()) line.append(" | offset cut ").append(cut);

        return line.toString();
    }

    private void checkTimeouts() {
        long now = System.currentTimeMillis();
        listeners.removeIf(listener -> {
            Long startTime = listenerStartTime.get(listener);
            if (startTime == null) return false;
            DebugSettings settings = listenerSettings.get(listener);
            if (settings == null || settings.timeoutSeconds() <= 0) return false;
            if (now - startTime >= settings.timeoutSeconds() * 1000L) {
                listenerSettings.remove(listener);
                listenerStartTime.remove(listener);
                listener.sendMessage(Component.text("Debug for " + player.getName() + " timed out.", NamedTextColor.GRAY));
                return true;
            }
            return false;
        });
    }

    private boolean shouldSend(DebugSettings settings, double offset, boolean isFlag) {
        if (!settings.isFiltered()) return true;
        for (Filter f : settings.filters()) {
            boolean match = switch (f) {
                case FLAGS_ONLY -> isFlag;
                case ELYTRA -> player.isGliding || player.wasGliding;
                case THRESHOLD -> offset >= settings.threshold();
            };
            if (match) return true;
        }
        return false;
    }

    private String pickColor(double offset, double totalOffset) {
        if (player.getSetbackTeleportUtil().blockOffsets) return "gray";
        if (offset <= 0 || totalOffset <= 0) {
            return "gray";
        } else if (offset < 0.0001) {
            return "green";
        } else if (offset < 0.01) {
            return "yellow";
        } else {
            return "red";
        }
    }

    public boolean startListening(GrimPlayer listener, DebugSettings settings) {
        if (listeners.contains(listener)) return false;
        listeners.add(listener);
        listenerSettings.put(listener, new DebugSettings(settings));
        listenerStartTime.put(listener, System.currentTimeMillis());
        if (settings.bufferSize() != pasteBuffer.getMaxSize()) {
            resizeBuffer(settings.bufferSize());
        }
        return true;
    }

    public boolean stopListening(GrimPlayer listener) {
        if (!listeners.remove(listener)) return false;
        listenerSettings.remove(listener);
        listenerStartTime.remove(listener);
        return true;
    }

    @Override
    public boolean toggleListener(GrimPlayer listener) {
        if (listeners.remove(listener)) {
            listenerSettings.remove(listener);
            listenerStartTime.remove(listener);
            return false;
        }
        listeners.add(listener);
        listenerStartTime.put(listener, System.currentTimeMillis());
        return true;
    }

    public boolean isListening(GrimPlayer listener) {
        return listeners.contains(listener);
    }

    public DebugSettings getListenerSettings(GrimPlayer listener) {
        return listenerSettings.getOrDefault(listener, new DebugSettings());
    }

    @Override
    public boolean toggleConsoleOutput() {
        this.outputToConsole = !outputToConsole;
        return this.outputToConsole;
    }

    public void pasteBuffer(Sender sender) {
        if (pasteBuffer.isEmpty()) {
            sender.sendMessage(Component.text("Debug buffer is empty.", NamedTextColor.RED));
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Player: ").append(player.user.getName());
        sb.append("\nClient: ").append(player.getClientVersion().getReleaseName());
        sb.append("\nBrand: ").append(player.getBrand());
        sb.append("\nServer: ").append(PacketEvents.getAPI().getServerManager().getVersion().getReleaseName());
        sb.append("\nPing: ").append(player.getTransactionPing()).append("ms");
        sb.append("\nTicks buffered: ").append(pasteBuffer.size());
        sb.append("\n\n");

        for (String line : pasteBuffer) {
            sb.append(line).append("\n");
        }

        GrimLog.sendLogAsync(sender, sb.toString(), string -> {}, "text/yaml");
    }
}
