package ac.grim.grimac.checks.impl.combat;

import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.player.GrimPlayer;

@CheckData(name = "Hitboxes", stableKey = "grim.combat.hitboxes", setback = 10, decay = 0.15, description = "Tried to hit an entity outside its valid hitbox")
public class Hitboxes extends Check {
    public Hitboxes(GrimPlayer player) {
        super(player);
    }
}
