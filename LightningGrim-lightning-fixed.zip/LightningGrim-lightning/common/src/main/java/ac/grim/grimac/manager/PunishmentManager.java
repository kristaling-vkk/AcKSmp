package ac.grim.grimac.manager;

import ac.grim.grimac.GrimAPI;
import ac.grim.grimac.api.AbstractCheck;
import ac.grim.grimac.api.config.ConfigManager;
import ac.grim.grimac.api.config.ConfigReloadable;
import ac.grim.grimac.api.event.events.CommandExecuteEvent;
import ac.grim.grimac.checks.Check;
import ac.grim.grimac.events.packets.ProxyAlertMessenger;
import ac.grim.grimac.platform.api.player.PlatformPlayer;
import ac.grim.grimac.player.GrimPlayer;
import ac.grim.grimac.utils.anticheat.LogUtil;
import ac.grim.grimac.utils.anticheat.MessageUtil;
import lombok.RequiredArgsConstructor;
import net.kyori.adventure.text.Component;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

public class PunishmentManager implements ConfigReloadable {
    private static final CommandExecuteEvent.Channel COMMAND_CHANNEL = GrimAPI.INSTANCE.getEventBus().get(CommandExecuteEvent.class);
    private final GrimPlayer player;
    private final List<PunishGroup> groups = new ArrayList<>();
    private String experimentalSymbol = "*";
    private String alertString;
    private boolean testMode;
    private String reasonFormat;
    private String proxyAlertString = "";

    public PunishmentManager(GrimPlayer player) {
        this.player = player;
    }

    @Override
    public void reload(ConfigManager config) {
        List<String> punish = config.getStringListElse("Punishments", new ArrayList<>());
        experimentalSymbol = config.getStringElse("experimental-symbol", "*");

        alertString = config.getStringElse(
                "alerts-format",
                "%prefix% &f%player% &bfailed <hover:show_text:\"&b%check_name%%experimental%\\n&8Description: &f%description%\">&f%check_name%%experimental%</hover> &f(x&c%vl%&f) &7%verbose%"
        );

        reasonFormat = config.getStringElse("alerts-reason-format", "\n&8Reason: &f%reason%");

        testMode = config.getBooleanElse("test-mode", false);

        proxyAlertString = config.getStringElse(
                "alerts-format-proxy",
                "%prefix% &f[&cproxy&f] &f%player% &bfailed <hover:show_text:\"&b%check_name%%experimental%\\n&8Description: &f%description%\">&f%check_name%%experimental%</hover> &f(x&c%vl%&f) &7%verbose%"
        );

        try {
            groups.clear();

            // To support reloading
            for (AbstractCheck check : player.getChecks()) {
                check.setEnabled(false);
            }

            for (Object s : punish) {
                LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) s;

                List<String> checks = (List<String>) map.getOrDefault("checks", new ArrayList<>());
                List<String> commands = (List<String>) map.getOrDefault("commands", new ArrayList<>());
                // Seconds; groups without the key keep their violations for 45 minutes
                int removeViolationsAfter = (int) map.getOrDefault("remove-violations-after", 2700);

                List<ParsedCommand> parsed = new ArrayList<>();
                List<AbstractCheck> checksList = new ArrayList<>();
                List<AbstractCheck> excluded = new ArrayList<>();
                for (String command : checks) {
                    command = command.toLowerCase(Locale.ROOT);
                    boolean exclude = false;
                    if (command.startsWith("!")) {
                        exclude = true;
                        command = command.substring(1);
                    }
                    for (AbstractCheck check : player.getChecks()) { // o(n) * o(n)?
                        if (check.getCheckName().toLowerCase(Locale.ROOT).contains(command)
                                || check.getAlternativeName().toLowerCase(Locale.ROOT).contains(command)) { // Some checks have equivalent names like AntiKB and AntiKnockback
                            if (exclude) {
                                excluded.add(check);
                            } else {
                                checksList.add(check);
                            }
                        }
                    }
                    for (AbstractCheck check : excluded) checksList.remove(check);
                }
                for (AbstractCheck check : checksList) {
                    check.setEnabled(true);
                }

                for (String command : commands) {
                    try {
                        int colon = command.indexOf(":");
                        int space = command.indexOf(" ");
                        if (colon <= 0 || space <= colon) {
                            LogUtil.error("Skipping malformed punishment entry (checks=" + checks + ", expected threshold:interval command): " + command);
                            continue;
                        }
                        int threshold = Integer.parseInt(command.substring(0, colon));
                        int interval = Integer.parseInt(command.substring(colon + 1, space));
                        String commandString = command.substring(space + 1);
                        parsed.add(new ParsedCommand(threshold, interval, commandString));
                    } catch (NumberFormatException ex) {
                        LogUtil.error("Skipping punishment entry (checks=" + checks + ") - threshold/interval not a number: " + command);
                    }
                }

                groups.add(new PunishGroup(checksList, parsed, removeViolationsAfter * 1000));
            }
        } catch (Exception e) {
            LogUtil.error("Error while loading punishments.yml! This is likely your fault!", e);
        }
    }

    private String replaceAlertPlaceholders(String original, int vl, Check check, String verbose) {
        return MessageUtil.replacePlaceholders(player, original
                .replace("[alert]", alertString)
                .replace("[proxy]", proxyAlertString)
                .replace("%check_name%", check.getDisplayName())
                .replace("%experimental%", check.isExperimental() ? experimentalSymbol : "")
                .replace("%vl%", Integer.toString(vl))
                .replace("%description%", check.getDescription())
                .replace("%stable_key%", check.getStableKey())
        ).replace("%verbose%", MessageUtil.miniMessageSafe(verbose))
                .replace("%reason%", buildReason(check));
    }

    private String buildReason(Check check) {
        String reason = check.getAlertReason();
        if (reason.isEmpty()) return "";
        // escapeTags leaves quotes alone, and the reason lands inside a hover:show_text:"..." argument
        return reasonFormat.replace("%reason%",
                MessageUtil.miniMessageSafe(reason.replace('"', '\'').replace('\\', '/')));
    }

    public boolean handleAlert(GrimPlayer player, String verbose, Check check) {
        String value = verbose == null ? "" : verbose;
        return handleAlert(player, () -> value, check);
    }

    public boolean handleAlert(GrimPlayer player, Supplier<String> verbose, Check check) {
        boolean sentDebug = false;

        // Check commands
        for (PunishGroup group : groups) {
            if (group.checks.contains(check)) {
                final int vl = getViolations(group, check);
                final int violationCount = group.violations.size();
                for (ParsedCommand command : group.commands) {
                    @Nullable Set<@Nullable PlatformPlayer> verboseListeners = null;
                    // Verbose that prints all flags: /grim verbose subscribers get EVERY flag, not just thresholded
                    // alerts. The verbose string is only rendered (safeGet) when there are listeners, so the flag
                    // path stays lazy when nobody is subscribed.
                    if (command.command.equals("[alert]") && GrimAPI.INSTANCE.getAlertManager().hasVerboseListeners()) {
                        sentDebug = true;
                        String verboseForListeners = safeGet(verbose);
                        String listenerCmd = replaceAlertPlaceholders(command.command, vl, check, verboseForListeners);
                        verboseListeners = GrimAPI.INSTANCE.getAlertManager().sendVerbose(MessageUtil.miniMessage(listenerCmd), null, player.user.getName());
                    }
                    if (violationCount >= command.threshold) {
                        boolean shouldRun = command.interval == 0
                                ? command.executeCount == 0
                                : violationCount >= command.nextBoundary;
                        if (shouldRun) {
                            String renderedVerbose = safeGet(verbose);
                            String cmd = replaceAlertPlaceholders(command.command, vl, check, renderedVerbose);
                            boolean canceled = COMMAND_CHANNEL.fire(player, check, renderedVerbose, cmd);
                            if (command.interval == 0) {
                                command.executeCount++;
                            } else {
                                advanceBoundary(command, violationCount);
                            }
                            if (canceled) continue;

                            switch (command.command) {
                                case "[webhook]" -> GrimAPI.INSTANCE.getDiscordManager().sendAlert(player, renderedVerbose, check.getDisplayName(), vl);
                                case "[log]" -> {
                                    // Binary flags already stored a row; avoid an extra legacy text row.
                                    if (!check.isLastFlagStoredBinaryVerbose()) {
                                        String verboseWithoutGl = renderedVerbose.replaceAll(" /gl .*", "");
                                        GrimAPI.INSTANCE.getDataStoreLifecycle().liveWriteHooks()
                                                .recordFlagFromCheck(player, check, vl, verboseWithoutGl);
                                    }
                                }
                                case "[proxy]" -> ProxyAlertMessenger.sendPluginMessage(cmd);
                                case "[alert]" -> {
                                    sentDebug = true;
                                    Component message = MessageUtil.miniMessage(cmd);
                                    if (testMode) { // secret test mode
                                        if (verboseListeners == null || verboseListeners.contains(player.platformPlayer)) {
                                            player.sendMessage(message);
                                        }
                                    } else {
                                        GrimAPI.INSTANCE.getAlertManager().sendAlert(message, verboseListeners, player.user.getName());
                                    }
                                }
                                default -> GrimAPI.INSTANCE.getScheduler().getGlobalRegionScheduler().run(GrimAPI.INSTANCE.getGrimPlugin(), () ->
                                        GrimAPI.INSTANCE.getPlatformServer().dispatchCommand(
                                                GrimAPI.INSTANCE.getPlatformServer().getConsoleSender(),
                                                cmd
                                        )
                                );
                            }
                        }

                        if (command.interval > 0) command.executeCount++;
                    } else {
                        // Interval commands re-arm after the active rolling count
                        // cools below their threshold.
                        command.nextBoundary = command.threshold;
                    }
                }
            }
        }

        return sentDebug;
    }

    private static String safeGet(Supplier<String> supplier) {
        try {
            String value = supplier.get();
            return value == null ? "" : value;
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static void advanceBoundary(ParsedCommand command, int violationCount) {
        command.nextBoundary += ((violationCount - command.nextBoundary) / command.interval + 1) * command.interval;
    }

    public void handleViolation(Check check) {
        for (PunishGroup group : groups) {
            if (group.checks.contains(check)) {
                long currentTime = TimeUnit.NANOSECONDS.toMillis(System.nanoTime());

                group.violations.record(currentTime, check, group.removeViolationsAfter);
            }
        }
    }

    private int getViolations(PunishGroup group, Check check) {
        return group.violations.count(check);
    }
}

@RequiredArgsConstructor
class PunishGroup {
    public final List<AbstractCheck> checks;
    public final List<ParsedCommand> commands;
    public final ViolationHistory<AbstractCheck> violations = new ViolationHistory<>();
    public final int removeViolationsAfter; // time to remove violations after in milliseconds
}

class ParsedCommand {
    public final int threshold;
    public final int interval;
    public final String command;
    // Legacy M=0 gate: execute once for this loaded command state.
    public int executeCount;
    // For M>0, the next active violation count that should run this command.
    public int nextBoundary;

    public ParsedCommand(int threshold, int interval, String command) {
        this.threshold = threshold;
        this.interval = interval;
        this.command = command;
        this.nextBoundary = threshold;
    }
}
